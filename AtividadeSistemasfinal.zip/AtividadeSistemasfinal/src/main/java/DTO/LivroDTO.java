/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author aluno.den
 */
public class LivroDTO {
    
    private String nomeLivro, autorLivro,genero ,lancamento,status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    private int id;

    public String getGeneroLivro() {
        return genero;
    }

    public void setGeneroLivro(String genero) {
        this.genero = genero;
    }

    public String getLancamentoLivro() {
        return lancamento;
    }

    public void setLancamentoLivro(String lancamento) {
        this.lancamento = lancamento;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
 
    public String getNomeLivro() {
        return nomeLivro;
    }

    public void setNomeLivro(String nomeLivro) {
        this.nomeLivro = nomeLivro;
    }

  
    public String getAutorLivro() {
        return autorLivro;
    }

   
    public void setAutorLivro(String autorLivro) {
        this.autorLivro = autorLivro;
    }

    
}