/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.LivroDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno.den
 */
public class LivroDAO {

    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<LivroDTO> lista = new ArrayList<>();

    public void cadastrarLivro(LivroDTO livrodto) {

        String sql = "insert into tabela(nome, autor, genero, lancamento,status)values (?,?,?,?,?)";

        conn = new Conexao().conectaBd();

        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, livrodto.getNomeLivro());
            pstm.setString(2, livrodto.getAutorLivro());
            pstm.setString(3, livrodto.getGeneroLivro());
            pstm.setString(4, livrodto.getLancamentoLivro());
            pstm.setString(5, livrodto.getStatus());
            pstm.execute();
            pstm.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e + "LivroDAO");
        }

    }

    public ArrayList<LivroDTO> PesquisarLivro() {
        String sql = "select * from tabela";
        conn = new Conexao().conectaBd();

        try {
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();

            while (rs.next()) {
                LivroDTO livrodto = new LivroDTO();
                livrodto.setId(rs.getInt("id"));
                livrodto.setNomeLivro(rs.getString("nome"));
                livrodto.setAutorLivro(rs.getString("autor"));
                livrodto.setGeneroLivro(rs.getString("genero"));
                livrodto.setLancamentoLivro(rs.getString("lancamento"));
                livrodto.setStatus(rs.getString("status"));

                lista.add(livrodto);

            }

        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, erro + "Erro Pesuisar");
        }
        return lista;
    }

    // Método para alterar um funcionário
    public void alterarLivro(LivroDTO livrodto) {
        String sql = "UPDATE tabela SET nome = ?, autor = ?, genero = ?, lancamento = ?, status = ? WHERE id = ?";
        conn = new Conexao().conectaBd();

        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, livrodto.getNomeLivro());
            pstm.setString(2, livrodto.getAutorLivro());
            pstm.setString(3, livrodto.getGeneroLivro());
            pstm.setString(4, livrodto.getLancamentoLivro());
            pstm.setString(5, livrodto.getStatus());
            pstm.setInt(6, livrodto.getId());
            pstm.executeUpdate();
            pstm.close();

            JOptionPane.showMessageDialog(null, "Livro alterado com sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar livro: " + e.getMessage());
        }
    }

    // Método para excluir um funcionário
    public void excluirLivro(LivroDTO livrodto) {
        String sql = "DELETE FROM tabela WHERE id = ?";
        conn = new Conexao().conectaBd();

        try {
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, livrodto.getId());
            pstm.execute();
            pstm.close();

            JOptionPane.showMessageDialog(null, "Livro excluído com sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir livro: " + e.getMessage());
        }
    }
}
